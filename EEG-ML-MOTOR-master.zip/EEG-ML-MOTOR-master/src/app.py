"""Streamlit app for BCI Motor Imagery real-time simulation.

Users pick a subject (A01–A09), tweak window/gate params, and run the
sliding-window simulation against the existing test-session EEG using the
saved fusion model artifacts.
"""

from __future__ import annotations

import io
import time
from typing import Any, Dict, Optional, cast

import pandas as pd
import streamlit as st

from inference import (
    GateConfig,
    WindowConfig,
    available_subjects,
    run_simulation,
)


st.set_page_config(
    page_title="BCI Motor Imagery Simulation",
    page_icon="🧠",
    layout="wide",
)

st.title("🧠 BCI Motor Imagery – Real-Time Simulation")
st.caption("Uses saved fusion models (CSP + SVM/LDA) on BCICIV-2a test sessions.")


# ── Sidebar controls ─────────────────────────────────────────────────────────
with st.sidebar:
    st.header("Controls")
    subs = available_subjects()
    subject = st.selectbox("Subject", subs, index=0 if subs else None)

    st.subheader("Sliding Window")
    win_sec = st.slider("Window (sec)", 1.0, 4.0, 3.0, 0.25)
    step_sec = st.slider("Step (sec)", 0.1, 1.0, 0.25, 0.05)

    st.subheader("Stability Gate")
    gate_n = st.slider("Consecutive votes", 2, 10, 5, 1)
    conf_thr = st.slider("Min confidence", 0.3, 0.9, 0.55, 0.01)
    cooldown = st.slider("Cooldown (sec)", 0.0, 5.0, 2.0, 0.25)

    limit_windows = st.toggle("Limit windows (for quick demo)", value=False)
    max_windows = st.number_input("Max windows", min_value=10, max_value=2000, value=400, step=10, disabled=not limit_windows)

    run_btn = st.button("▶️ Run simulation", use_container_width=True, type="primary", disabled=not subject)


def download_link(df: pd.DataFrame, filename: str, label: str):
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    st.download_button(label, buf.getvalue(), file_name=filename, mime="text/csv")


def render_summary(meta: dict):
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Subject", meta["subject"])
    c2.metric("Commands fired", meta["commands_fired"])
    c3.metric("Windows processed", meta["n_windows"])
    c4.metric("EEG duration (s)", meta["eeg_duration_sec"])


def render_charts(log_df: pd.DataFrame):
    if log_df is None or log_df.empty:
        st.info("No prediction data to plot yet.")
        return

    pred_counts = log_df["pred_label"].value_counts() if "pred_label" in log_df.columns else pd.Series(dtype=int)
    class_counts = pd.DataFrame({
        "class": pred_counts.index.astype(str),
        "count": pred_counts.values,
    })
    conf_line = log_df.set_index("time_sec")["confidence"]
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**Predicted class counts**")
        st.bar_chart(class_counts, x="class", y="count", use_container_width=True)
    with c2:
        st.markdown("**Confidence over time**")
        st.line_chart(conf_line, use_container_width=True)


if run_btn:
    if not subject:
        st.warning("Select a subject to run the simulation.")
        st.stop()

    with st.spinner("Running simulation..."):
        start = time.time()
        result = run_simulation(
            subject=subject,
            gate_cfg=GateConfig(n=gate_n, threshold=conf_thr, cooldown_sec=cooldown),
            win_cfg=WindowConfig(win_sec=win_sec, step_sec=step_sec),
            max_windows=max_windows if limit_windows else None,
        )
        elapsed = time.time() - start

    raw_log_df = result.get("log_df")
    log_df = cast(pd.DataFrame, raw_log_df) if raw_log_df is not None else pd.DataFrame()

    raw_cmd_df = result.get("cmd_df")
    cmd_df = cast(pd.DataFrame, raw_cmd_df) if raw_cmd_df is not None else pd.DataFrame()
    meta = cast(Dict[str, Any], result.get("meta", {}))
    meta["elapsed_sec"] = round(elapsed, 2)

    st.success(f"Simulation complete in {elapsed:.2f}s")
    render_summary(meta)

    st.markdown("### Recent predictions")
    st.dataframe(log_df.tail(50), use_container_width=True, height=320)

    st.markdown("### Stable commands (timeline)")
    if cmd_df.empty:
        st.info("No stable commands fired. Try reducing gate N or confidence threshold.")
    else:
        st.dataframe(cmd_df, use_container_width=True, height=240)

    render_charts(log_df)

    st.markdown("### Downloads")
    d1, d2 = st.columns(2)
    with d1:
        download_link(log_df, f"{subject}_sim_log.csv", "Download log.csv")
    with d2:
        download_link(cmd_df, f"{subject}_commands.csv", "Download commands.csv")

else:
    st.info("Select a subject and click Run simulation to start.")
