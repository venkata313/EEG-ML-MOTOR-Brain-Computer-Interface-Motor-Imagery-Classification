"""Inference + simulation helpers for Streamlit UI.

This wraps the realtime simulation logic from `src/realtime_sim.py` into
cache-friendly functions the Streamlit app can call. It loads artifacts,
streams windows from the test session EEG, applies CSP + bandpower features,
and returns prediction logs plus stable commands.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import joblib
import numpy as np
import pandas as pd
from scipy.io import loadmat
from scipy.signal import butter, filtfilt, welch


# ── PATHS ────────────────────────────────────────────────────────────────────
BASE = Path(__file__).resolve().parent.parent
DATA_DIR = BASE / "data" / "raw"
ART_DIR = BASE / "artifacts"


# ── CONSTANTS ────────────────────────────────────────────────────────────────
SFREQ = 250  # Hz
CLASS_NAMES = {1: "LEFT HAND", 2: "RIGHT HAND", 3: "FEET", 4: "TONGUE"}
CLASS_EMOJI = {1: "←", 2: "→", 3: "↓", 4: "↑"}

BP_LOW, BP_HIGH = 8.0, 30.0
MU_BAND = (8, 12)
BETA_BAND = (13, 30)


# ── HELPERS ──────────────────────────────────────────────────────────────────
def find_mat_file(data_dir: Path, subj: str, session_letter: str = "E") -> Optional[Path]:
    candidates = [f"{subj}{session_letter}.mat", f"BCICIV_2a_{subj}{session_letter}.mat"]
    for name in candidates:
        p = data_dir / name
        if p.exists():
            return p
    # Fallback recursive search
    for root_dir in [data_dir, data_dir.parent]:
        for dirpath, _, fnames in os.walk(root_dir):
            for fname in sorted(fnames):
                low = fname.lower()
                if subj.lower() in low and session_letter.lower() in low and fname.endswith(".mat"):
                    return Path(dirpath) / fname
    return None


def butter_bandpass(data: np.ndarray, lo: float, hi: float, fs: float, order: int = 5) -> np.ndarray:
    b, a = butter(order, [lo / (fs / 2), hi / (fs / 2)], btype="band")
    return filtfilt(b, a, data, axis=-1)


def bandpower_features(epoch: np.ndarray, fs: float = SFREQ) -> np.ndarray:
    """Compute log-bandpower for mu and beta per channel.

    Args:
        epoch: shape (n_ch, n_times)
    Returns:
        1D array shape (n_ch * 2)
    """
    n_ch = epoch.shape[0]
    feats = np.zeros(n_ch * 2)
    for c in range(n_ch):
        sig = epoch[c, :]
        freqs, psd = welch(sig, fs=fs, nperseg=min(256, len(sig)))
        mu_mask = (freqs >= MU_BAND[0]) & (freqs <= MU_BAND[1])
        beta_mask = (freqs >= BETA_BAND[0]) & (freqs <= BETA_BAND[1])
        feats[c] = np.log(np.mean(psd[mu_mask]) + 1e-10)
        feats[n_ch + c] = np.log(np.mean(psd[beta_mask]) + 1e-10)
    return feats


def load_artifacts(subject: str) -> Dict[str, object]:
    model_path = ART_DIR / f"{subject}_fusion_model.pkl"
    if not model_path.exists():
        raise FileNotFoundError(f"No saved model found at {model_path}")
    bundle = joblib.load(model_path)
    return bundle


def load_test_eeg(subject: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Load and bandpass the test session EEG for a subject.

    Returns:
        eeg: (n_ch, total_samples)
        trial_starts: array of sample indices
        trial_labels: array of class ints
    """
    fname = find_mat_file(DATA_DIR, subject, "E")
    if fname is None:
        raise FileNotFoundError(f"Test session file not found for {subject}")

    mat = loadmat(fname, simplify_cells=True)
    data = mat.get("data")
    runs = data if isinstance(data, (list, np.ndarray)) else [data]

    eeg_segments: List[np.ndarray] = []
    all_trials: List[int] = []
    all_labels: List[int] = []
    offset = 0

    for run in runs:
        if run is None:
            continue
        try:
            X = run["X"]  # (samples, channels)
            y = run["y"]
            tri = run["trial"]
        except (TypeError, KeyError, IndexError):
            continue

        X = X[:, :22]  # EEG channels only
        X = butter_bandpass(X.T, BP_LOW, BP_HIGH, SFREQ).T
        eeg_segments.append(X)

        for idx, t in enumerate(tri):
            label = int(y[idx])
            if label > 0:
                all_trials.append(offset + t)
                all_labels.append(label)
        offset += X.shape[0]

    eeg = np.concatenate(eeg_segments, axis=0)  # (total_samples, 22)
    return eeg.T, np.array(all_trials), np.array(all_labels)


@dataclass
class GateConfig:
    n: int = 5
    threshold: float = 0.55
    cooldown_sec: float = 2.0


@dataclass
class WindowConfig:
    win_sec: float = 3.0
    step_sec: float = 0.25


class StabilityGate:
    def __init__(self, n: int, threshold: float, cooldown: float, sfreq: float, step: int):
        self.n = n
        self.threshold = threshold
        self.cooldown_samples = int(cooldown * sfreq / step)
        self.buffer: List[Tuple[int, float]] = []
        self.steps_since_last = self.cooldown_samples

    def update(self, pred_class: int, confidence: float) -> Tuple[Optional[int], bool]:
        self.steps_since_last += 1
        self.buffer.append((pred_class, confidence))
        if len(self.buffer) > self.n:
            self.buffer.pop(0)

        if len(self.buffer) < self.n:
            return None, False

        classes = [b[0] for b in self.buffer]
        confidences = [b[1] for b in self.buffer]
        all_same = all(c == classes[0] for c in classes)
        all_conf = all(cf >= self.threshold for cf in confidences)
        cooled_down = self.steps_since_last >= self.cooldown_samples

        if all_same and all_conf and cooled_down:
            self.steps_since_last = 0
            self.buffer = []
            return classes[0], True
        return None, False


def run_simulation(
    subject: str,
    gate_cfg: GateConfig,
    win_cfg: WindowConfig,
    max_windows: Optional[int] = None,
) -> Dict[str, object]:
    """Run sliding-window simulation and return logs + commands.

    Returns dict with:
        log_df: per-window predictions
        cmd_df: stable commands only
        meta: timings and counts
    """

    bundle = load_artifacts(subject)
    csp_model = bundle["csp"]
    clf = bundle["model"]

    has_proba = hasattr(clf, "predict_proba") or hasattr(getattr(clf, "named_steps", {}), "svm")

    eeg, trial_starts, trial_labels = load_test_eeg(subject)
    n_ch, total_samples = eeg.shape

    win_samp = int(win_cfg.win_sec * SFREQ)
    step_samp = int(win_cfg.step_sec * SFREQ)
    n_windows = (total_samples - win_samp) // step_samp
    if max_windows:
        n_windows = min(n_windows, max_windows)

    gate = StabilityGate(
        n=gate_cfg.n,
        threshold=gate_cfg.threshold,
        cooldown=gate_cfg.cooldown_sec,
        sfreq=SFREQ,
        step=step_samp,
    )

    log: List[Dict[str, object]] = []
    commands: List[Dict[str, object]] = []

    for i in range(n_windows):
        start = i * step_samp
        end = start + win_samp
        window = eeg[:, start:end]

        window_3d = window[np.newaxis, :, :]
        csp_feat = csp_model.transform(window_3d)[0]
        bp_feat = bandpower_features(window)
        feat_vec = np.hstack([csp_feat, bp_feat]).reshape(1, -1)

        pred_class = int(clf.predict(feat_vec)[0])
        confidence = 1.0
        if has_proba:
            try:
                proba = clf.predict_proba(feat_vec)[0]
                confidence = float(np.max(proba))
            except Exception:
                confidence = 1.0

        t_sec = start / SFREQ

        stable_class, fired = gate.update(pred_class, confidence)

        log.append(
            {
                "time_sec": round(t_sec, 3),
                "window_idx": i,
                "pred_class": pred_class,
                "pred_label": CLASS_NAMES[pred_class],
                "confidence": round(confidence, 4),
                "gate_fired": fired,
                "command": CLASS_NAMES[stable_class] if fired else "",
            }
        )

        if fired and stable_class is not None:
            commands.append(
                {
                    "time_sec": round(t_sec, 3),
                    "command": CLASS_NAMES[stable_class],
                    "class_id": stable_class,
                    "emoji": CLASS_EMOJI[stable_class],
                }
            )

    log_df = pd.DataFrame(log)
    cmd_df = pd.DataFrame(commands)

    meta = {
        "subject": subject,
        "n_windows": n_windows,
        "win_sec": win_cfg.win_sec,
        "step_sec": win_cfg.step_sec,
        "gate_n": gate_cfg.n,
        "conf_threshold": gate_cfg.threshold,
        "cooldown_sec": gate_cfg.cooldown_sec,
        "commands_fired": len(commands),
        "eeg_duration_sec": round(total_samples / SFREQ, 1),
    }

    return {"log_df": log_df, "cmd_df": cmd_df, "meta": meta}


def available_subjects() -> List[str]:
    subs = set()
    for p in ART_DIR.glob("*_fusion_model.pkl"):
        subs.add(p.name.split("_")[0])
    return sorted(subs)

