"""
Phase 5 - Real-Time Simulation
===============================
File  : src/realtime_sim.py
Place : /teamspace/studios/this_studio/bci_mi_project/src/realtime_sim.py

What it does:
  - Loads a saved fusion model (CSP + SVM/LDA) from artifacts/
  - Loads the test session EEG (.mat) for a chosen subject
  - Simulates live streaming by sliding a window across the raw EEG
  - Applies stability gate: fires a command only when N consecutive
    windows agree on the same class with confidence > threshold
  - Saves a full command log CSV to reports/

Checklist:
  [x] Phase 1 - Data inspection
  [x] Phase 2 - Preprocessing + epoch extraction
  [x] Phase 3 - Feature extraction
  [x] Phase 4 - Model training and evaluation
  [x] Phase 5 - Real-time simulation   ← THIS FILE
  [ ] Phase 6 - Streamlit UI
  [ ] Phase 7 - Report + PPT
"""

import numpy as np
import os, csv, time, joblib
import warnings
warnings.filterwarnings('ignore')

from scipy.io import loadmat
from scipy.signal import butter, filtfilt, welch
from mne.decoding import CSP   # only used for type reference; actual CSP loaded from pkl

# ── CONFIG ───────────────────────────────────────────────────────────────────
BASE      = "/teamspace/studios/this_studio/bci_mi_project"
DATA_DIR  = os.path.join(BASE, "data", "raw")
ART_DIR   = os.path.join(BASE, "artifacts")
REP_DIR   = os.path.join(BASE, "reports")
os.makedirs(REP_DIR, exist_ok=True)

SUBJECT   = "A01"          # ← change to any subject A01–A09
SFREQ     = 250            # Hz

# Sliding window settings
WIN_SEC   = 3.0            # window length in seconds
STEP_SEC  = 0.25           # step size in seconds  (4 predictions/sec)
WIN_SAMP  = int(WIN_SEC  * SFREQ)   # 750 samples
STEP_SAMP = int(STEP_SEC * SFREQ)   # 62 samples

# Bandpass (must match training)
BP_LOW, BP_HIGH = 8.0, 30.0

# Bandpower bands (must match Cell 2 training)
MU_BAND   = (8,  12)
BETA_BAND = (13, 30)

# Stability gate
CONF_THRESHOLD  = 0.55     # minimum confidence to count a prediction
GATE_WINDOW_N   = 5        # number of consecutive same-class predictions needed
COOLDOWN_SEC    = 2.0      # seconds to wait before next command can fire

CLASS_NAMES = {1: "LEFT HAND", 2: "RIGHT HAND", 3: "FEET", 4: "TONGUE"}
CLASS_EMOJI = {1: "←", 2: "→", 3: "↓", 4: "↑"}

# ── FILE DISCOVERY ────────────────────────────────────────────────────────────
def find_mat_file(data_dir, subj, session_letter):
    candidates = [f"{subj}{session_letter}.mat",
                  f"BCICIV_2a_{subj}{session_letter}.mat"]
    for name in candidates:
        p = os.path.join(data_dir, name)
        if os.path.exists(p):
            return p
    for root_dir in [data_dir, os.path.dirname(data_dir)]:
        for dirpath, _, fnames in os.walk(root_dir):
            for fname in sorted(fnames):
                low = fname.lower()
                if subj.lower() in low and session_letter.lower() in low and fname.endswith('.mat'):
                    return os.path.join(dirpath, fname)
    return None

# ── SIGNAL HELPERS ────────────────────────────────────────────────────────────
def butter_bandpass(data, lo, hi, fs, order=5):
    b, a = butter(order, [lo / (fs/2), hi / (fs/2)], btype='band')
    return filtfilt(b, a, data, axis=-1)

def bandpower_features(epoch, fs=SFREQ):
    """
    epoch: (n_ch, n_times)
    Returns: 1D feature vector (n_ch * 2)  — mu + beta bandpower per channel
    """
    n_ch = epoch.shape[0]
    feats = np.zeros(n_ch * 2)
    for c in range(n_ch):
        sig = epoch[c, :]
        freqs, psd = welch(sig, fs=fs, nperseg=min(256, len(sig)))
        mu_mask   = (freqs >= MU_BAND[0])   & (freqs <= MU_BAND[1])
        beta_mask = (freqs >= BETA_BAND[0]) & (freqs <= BETA_BAND[1])
        feats[c]        = np.log(np.mean(psd[mu_mask])   + 1e-10)
        feats[n_ch + c] = np.log(np.mean(psd[beta_mask]) + 1e-10)
    return feats

# ── LOAD CONTINUOUS EEG (test session) ────────────────────────────────────────
def load_continuous_eeg(subj):
    """
    Loads all runs of the test session and concatenates into one
    continuous EEG array: (n_ch, total_samples).
    Also returns trial info for ground-truth comparison.
    """
    fname = find_mat_file(DATA_DIR, subj, "E")
    if fname is None:
        raise FileNotFoundError(f"Test session file not found for {subj}")

    mat  = loadmat(fname, simplify_cells=True)
    data = mat["data"]
    runs = data if isinstance(data, (list, np.ndarray)) else [data]

    eeg_segments, all_trials, all_labels = [], [], []
    offset = 0

    for run in runs:
        try:
            X   = run["X"]        # (samples, channels)
            y   = run["y"]
            tri = run["trial"]
        except (TypeError, KeyError, IndexError):
            continue

        X = X[:, :22]                                           # EEG only
        X = butter_bandpass(X.T, BP_LOW, BP_HIGH, SFREQ).T     # (samples, 22)
        eeg_segments.append(X)

        for idx, t in enumerate(tri):
            label = int(y[idx])
            if label > 0:
                all_trials.append(offset + t)
                all_labels.append(label)
        offset += X.shape[0]

    eeg = np.concatenate(eeg_segments, axis=0)   # (total_samples, 22)
    return eeg.T, np.array(all_trials), np.array(all_labels)  # (22, total_samples)

# ── STABILITY GATE ────────────────────────────────────────────────────────────
class StabilityGate:
    """
    Fires a stable command only when:
      - last N predictions agree on the same class, AND
      - each prediction had confidence >= threshold, AND
      - cooldown period has elapsed since last command
    """
    def __init__(self, n=GATE_WINDOW_N, threshold=CONF_THRESHOLD, cooldown=COOLDOWN_SEC, sfreq=SFREQ, step=STEP_SAMP):
        self.n          = n
        self.threshold  = threshold
        self.cooldown_samples = int(cooldown * sfreq / step)   # in steps
        self.buffer     = []    # list of (class, confidence)
        self.steps_since_last = self.cooldown_samples          # start ready

    def update(self, pred_class, confidence):
        """
        Returns (stable_command, trigger_fired)
        stable_command: class int if gate fires, else None
        """
        self.steps_since_last += 1
        self.buffer.append((pred_class, confidence))
        if len(self.buffer) > self.n:
            self.buffer.pop(0)

        if len(self.buffer) < self.n:
            return None, False

        classes     = [b[0] for b in self.buffer]
        confidences = [b[1] for b in self.buffer]
        all_same    = all(c == classes[0] for c in classes)
        all_conf    = all(cf >= self.threshold for cf in confidences)
        cooled_down = self.steps_since_last >= self.cooldown_samples

        if all_same and all_conf and cooled_down:
            self.steps_since_last = 0
            self.buffer = []      # reset after firing
            return classes[0], True

        return None, False

# ── MAIN SIMULATION ────────────────────────────────────────────────────────────
def run_simulation(subject=SUBJECT):
    print(f"\n{'='*60}")
    print(f"  BCI Real-Time Simulation  |  Subject: {subject}")
    print(f"  Window: {WIN_SEC}s  |  Step: {STEP_SEC}s  |  Gate: {GATE_WINDOW_N} × {CONF_THRESHOLD:.0%}")
    print(f"{'='*60}\n")

    # Load model
    model_path = os.path.join(ART_DIR, f"{subject}_fusion_model.pkl")
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"No saved model found at {model_path}\n"
                                f"Run Cell 2 (04_cell2_FUSION_training.py) first.")
    bundle    = joblib.load(model_path)
    csp_model = bundle['csp']
    clf       = bundle['model']           # SVM or LDA pipeline

    # Check if classifier supports probability
    has_proba = hasattr(clf, 'predict_proba') or hasattr(clf.named_steps.get('svm', None), 'predict_proba')

    # Load continuous EEG
    print(f"Loading test session EEG for {subject}...")
    eeg, trial_starts, trial_labels = load_continuous_eeg(subject)
    n_ch, total_samples = eeg.shape
    print(f"  EEG shape: {n_ch} channels × {total_samples} samples ({total_samples/SFREQ:.1f}s)\n")

    # Simulation loop
    gate     = StabilityGate()
    log      = []          # all predictions
    commands = []          # stable commands only
    n_windows = (total_samples - WIN_SAMP) // STEP_SAMP

    print(f"{'Time':>7}  {'Pred':>12}  {'Conf':>6}  {'Gate':>6}  {'Command'}")
    print("-" * 55)

    for i in range(n_windows):
        start = i * STEP_SAMP
        end   = start + WIN_SAMP
        window = eeg[:, start:end]         # (22, 750)

        # Feature extraction
        window_3d  = window[np.newaxis, :, :]               # (1, 22, 750)
        csp_feat   = csp_model.transform(window_3d)[0]      # (8,)
        bp_feat    = bandpower_features(window)              # (44,)
        feat_vec   = np.hstack([csp_feat, bp_feat]).reshape(1, -1)

        # Prediction
        pred_class = int(clf.predict(feat_vec)[0])
        if has_proba:
            try:
                proba = clf.predict_proba(feat_vec)[0]
                confidence = float(np.max(proba))
            except Exception:
                confidence = 1.0
        else:
            confidence = 1.0

        t_sec = start / SFREQ

        # Stability gate
        stable_class, fired = gate.update(pred_class, confidence)

        # Log every prediction
        log.append({
            'time_sec':   round(t_sec, 3),
            'window_idx': i,
            'pred_class': pred_class,
            'pred_label': CLASS_NAMES[pred_class],
            'confidence': round(confidence, 4),
            'gate_fired': fired,
            'command':    CLASS_NAMES[stable_class] if fired else ''
        })

        # Print and log stable commands
        gate_str = "🔴" if not fired else "🟢"
        if fired:
            cmd = CLASS_NAMES[stable_class]
            emoji = CLASS_EMOJI[stable_class]
            commands.append({'time_sec': round(t_sec,3), 'command': cmd})
            print(f"{t_sec:>6.2f}s  {CLASS_NAMES[pred_class]:>12}  {confidence:>5.1%}  {gate_str}    "
                  f"★ COMMAND: {emoji} {cmd}")
        else:
            # Print only every 2 seconds to avoid clutter
            if i % (int(2.0 / STEP_SEC)) == 0:
                print(f"{t_sec:>6.2f}s  {CLASS_NAMES[pred_class]:>12}  {confidence:>5.1%}  {gate_str}")

    # Save logs
    log_path = os.path.join(REP_DIR, f"{subject}_sim_log.csv")
    cmd_path = os.path.join(REP_DIR, f"{subject}_commands.csv")

    with open(log_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=log[0].keys())
        writer.writeheader()
        writer.writerows(log)

    with open(cmd_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['time_sec', 'command'])
        writer.writeheader()
        writer.writerows(commands)

    print(f"\n{'='*60}")
    print(f"  Simulation complete!")
    print(f"  Total windows processed : {n_windows}")
    print(f"  Stable commands fired   : {len(commands)}")
    print(f"  Full log saved          : {log_path}")
    print(f"  Command log saved       : {cmd_path}")
    print(f"{'='*60}\n")

    if commands:
        print("📋 Command Timeline:")
        for c in commands:
            print(f"   t={c['time_sec']:>7.2f}s  →  {c['command']}")

    return log, commands

# ── RUN ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # Change SUBJECT above to test different subjects
    log, commands = run_simulation(SUBJECT)